$('.toggle i').click(function () {
    $('ul').toggleClass("show");
});